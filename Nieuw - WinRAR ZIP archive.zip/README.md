npm install
npm run dev

Go to localhost:3000